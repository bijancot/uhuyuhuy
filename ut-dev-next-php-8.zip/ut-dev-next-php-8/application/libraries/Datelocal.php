<?php
    class Datelocal {
        public function __construct(){
            date_default_timezone_set("Asia/Bangkok");
        }
    }
?>